INSERT INTO "case" (id, case_name, case_steps, case_type, case_id, default_result) VALUES (1, '边界分析', null, '边界分析', null, 'True');
INSERT INTO "case" (id, case_name, case_steps, case_type, case_id, default_result) VALUES (2, '参数组合', null, '参数组合', null, 'True');
INSERT INTO "case" (id, case_name, case_steps, case_type, case_id, default_result) VALUES (3, '异常情况', null, '异常情况', null, 'True');
INSERT INTO "case" (id, case_name, case_steps, case_type, case_id, default_result) VALUES (4, '性能测试', null, '性能测试', null, 'True');
INSERT INTO "case" (id, case_name, case_steps, case_type, case_id, default_result) VALUES (5, '安全测试', null, '安全测试', null, 'True');